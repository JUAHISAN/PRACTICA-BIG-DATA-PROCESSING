package io.keepcoding.data.simulator.batch
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import spark.implicits._
import org.apache.spark.sql.functions.{sum, when}
import org.apache.spark.sql.types.TimestampType



object BatchJobImpl extends BatchJob 
{


	override val spark: SparkSession = SparkSession
		.builder()
		.master("local[*]")
		.appName("Spark SQL KeepCoding Base")
		.getOrCreate()



	override def appTX(df: DataFrame): DataFrame = 
	{

		df
		.select($"bytes", $"app")
		.groupBy($"app")
		.agg(sum($"bytes").as("sum_bytes_app"))
		.select($"app", $"sum_bytes_app")
	}



	override def userOQ(df: DataFrame): DataFrame = 
	{

		df
		.select($"bytes", $"email", $"quota")
		.groupBy($"email", $"quota")
		.agg(sum($"bytes").as("sum_bytes_user"))
		.filter("sum_bytes_user > quota")
		.select($"email")
	}


	override def readDDBB(DDBBpath: String, year: String, month: String, day: String, hour: String): DataFrame = 
	{

		spark
		.read
		.format("parquet")
		.load(s"${DDBBpath}/data")
		.filter($"year" === year && $"month" === month && $"day" === day && $"hour" === hour)
	}
	
		

	override def userTX(df: DataFrame): DataFrame = 
	{
	
		df
		.select($"bytes", $"email")
		.groupBy($"email")
		.agg(sum($"bytes").as("sum_bytes_user"))
		.select($"email", $"sum_bytes_user")
	}



	override def writeJDBC(df: DataFrame, JDBCUrl: String, JDBCTable: String, user: String, password: String): Unit = 
	{

		df
		.write
		.mode(SaveMode.Append)
		.format("jdbc")
		.option("driver", "org.postgresql.Driver")
		.option("url", JDBCUrl)
		.option("dbtable", JDBCTable)
		.option("user", user)
		.option("password", password)
		.save()
	}
	
	
	
	override def readAntenna(df: DataFrame): DataFrame = 
	{
    
		df
		.select($"bytes", $"antenna_id")
		.groupBy($"antenna_id")
		.agg(sum($"bytes").as("sum_bytes_antenna"))
		.select($"antenna_id", $"sum_bytes_antenna")
	}
	
	

	def main(args: Array[String]): Unit = run(args)
	
}

package io.keepcoding.data.simulator.batch
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}
import org.apache.spark.sql.{DataFrame, SparkSession}
import java.sql.Timestamp
import java.time.OffsetDateTime


case class ManagementInfo(timestamp: Long, id: String, antenna_id: String, bytes: Long, app: String)

trait BatchJob 
{


	val spark: SparkSession
	def appTX(df: DataFrame): DataFrame
	def userOQ(df: DataFrame): DataFrame
  	def writeJDBC(df: DataFrame, JDBCUrl: String, JDBCTable: String, user: String, password: String): Unit
	def readDDBB(DDBBpath: String, year: String, month: String, day: String, hour: String): DataFrame
	def readAntenna(df: DataFrame): DataFrame
	def userTX(df: DataFrame): DataFrame

  	

	def run(args: Array[String]): Unit = 
	{
		val Array(year, month, day, hour, DDBBpath, JDBCUrl, JDBCUser, JDBCPwd, aggJDBCAntennaTable, aggJDBCUserTable, aggJDBCAppTable, aggJDBCQuotaTable) = args
    		println(s"Arrancando: ${args.toSeq}")

		val aggByAppDF = appTX(devicesDF)
		val aggByQuotaDF = userOQ(devicesDF)
    		val devicesDF = readDDBB(DDBBpath, year, month, day, hour)
		val aggByAntennaDF = readAntenna(devicesDF)
		val aggByUserDF = userTX(devicesDF)


		writeJDBC(aggByAntennaDF, JDBCUrl, aggJDBCAntennaTable, JDBCUser, JDBCPwd)
		writeJDBC(aggByAppDF, JDBCUrl, aggJDBCAppTable, JDBCUser, JDBCPwd)
		writeJDBC(aggByQuotaDF, JDBCUrl, aggJDBCQuotaTable, JDBCUser, JDBCPwd)
		writeJDBC(aggByUserDF, JDBCUrl, aggJDBCUserTable, JDBCUser, JDBCPwd)


    		spark.close()

// ARGS: <YEAR> <MONTH> <DAY> <HOUR> /tmp/data-simulator jdbc:postgresql://localhost/postgres postgres postgres batch_bytes_by_antenna_agg batch_bytes_by_user_agg batch_bytes_by_app_agg batch_over_quota_agg

	}
	
}

package io.keepcoding.data.simulator.streaming
import scala.concurrent.{Await, Future}
import scala.concurrent.duration.Duration
import io.keepcoding.data.simulator.streaming.StreamingJobImpl._
import org.apache.spark.sql.{DataFrame, SparkSession}
import scala.concurrent.ExecutionContext.Implicits.global




case class ManagementInfo(timestamp: Long, id: String, antenna_id: String, bytes: Long, app: String)



trait StreamingJob 
{

	val spark: SparkSession
	def readKAFKA(KAFKAserver: String, topic: String): DataFrame
	def parserJSON(df: DataFrame): DataFrame
	def readUserMetadata(JDBCUrl: String, JDBCTable: String, user: String, password: String): DataFrame
	def enrichDevicesWithUserMetadata(devicesDF: DataFrame, userMetadataDF: DataFrame): DataFrame
	def readAntenna(df: DataFrame): DataFrame
	def userTX(df: DataFrame): DataFrame
	def appTX(df: DataFrame): DataFrame

   	 def run(args: Array[String]): Unit = 
   	 {

		val Array(KAFKAserver, topic, JDBCUrl, JDBCMetadataTable, aggAntennaTable, aggUserTable, aggAppTable, JDBCUser, JDBCPwd, DDBBpath) = args
		println(s"Arrancando: ${args.toSeq}")
		
		val aggByAntennaDF = readAntenna(devicesMetadataDF)
      		val aggByUserDF = userTX(devicesMetadataDF)
      		val aggByAppDF = appTX(devicesMetadataDF)

		val kafkaDF = readKAFKA(KAFKAserver, topic)
		val devicesDF = parserJSON(kafkaDF)
		val userMetadataDF = readUserMetadata(JDBCUrl, JDBCMetadataTable, JDBCUser, JDBCPwd)
		val devicesMetadataDF = enrichDevicesWithUserMetadata(devicesDF, userMetadataDF)
		val DDBBfuture = writeDDBB(devicesMetadataDF, DDBBpath)

      		val aggAntennaFuture = writeJDBC(aggByAntennaDF, JDBCUrl, aggAntennaTable, JDBCUser, JDBCPwd)
      		val aggUserFuture = writeJDBC(aggByUserDF, JDBCUrl, aggUserTable, JDBCUser, JDBCPwd)
      		val aggAppFuture = writeJDBC(aggByAppDF, JDBCUrl, aggAppTable, JDBCUser, JDBCPwd)

      		Await.result(Future.sequence(Seq(DDBBfuture, aggAntennaFuture, aggUserFuture, aggAppFuture)), Duration.Inf)


      spark.close()

// ARGS: KAFKA_SERVER:9092 devices jdbc:postgresql://localhost:5432/postgres bytes_by_antenna_agg bytes_by_user_agg bytes_by_app_agg user_metadata postgres postgres localhost/data-simulator/
	
	}

}

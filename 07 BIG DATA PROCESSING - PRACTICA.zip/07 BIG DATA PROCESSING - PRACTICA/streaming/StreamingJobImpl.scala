package io.keepcoding.data.simulator.streaming
import spark.implicits._
import org.apache.spark.sql.catalyst.ScalaReflection
import scala.concurrent.ExecutionContext.Implicits.global
import org.apache.spark.sql.functions.{col, dayofmonth, from_json, hour, month, sum, window, year}
import org.apache.spark.sql.types.{StringType, StructType, TimestampType}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import scala.concurrent.Future



object StreamingJobImpl extends StreamingJob 
{

	override val spark: SparkSession = SparkSession
		.builder()
		.master("local[20]")
		.appName("Spark SQL KeepCoding Base")
		.getOrCreate()



	override def readKAFKA(KAFKAserver: String, topic: String): DataFrame = 
	{
		
		spark
		.readStream
		.format("kafka")
		.option("kafka.bootstrap.servers", KAFKAserver)
		.option("subscribe", topic)
		.load()
	
	}



	override def parserJSON(df: DataFrame): DataFrame = 
	{
	
		val schema: StructType = ScalaReflection.schemaFor[ManagementInfo].dataType.asInstanceOf[StructType]
			df
			.select(from_json(col("value").cast(StringType), schema).as("json"))
			.select("json.*")
	}
	
	

	override def readUserMetadata(JDBCUrl: String, JDBCTable: String, user: String, password: String): DataFrame = 
	{
	
		spark
		.read
		.format("jdbc")
		.option("url", JDBCUrl)
		.option("dbtable", JDBCTable)
		.option("user", user)
		.option("password", password)
		.load()

	}



	override def enrichDevicesWithUserMetadata(devicesDF: DataFrame, userMetadataDF: DataFrame): DataFrame = 
	{
	
		devicesDF.as("device")
		.join(userMetadataDF.as("userMetadata"), $"device.id" === $"userMetadata.id").drop($"userMetadata.id")
	}



	def writeDDBB(df: DataFrame, storageRootPath: String): Future[Unit] = Future 
	{
	
		val columns = df.columns.map(col).toSeq ++ Seq(year(($"timestamp").cast(TimestampType)).as("year"),
								month(($"timestamp").cast(TimestampType)).as("month"),
								dayofmonth(($"timestamp").cast(TimestampType)).as("day"),
								hour(($"timestamp").cast(TimestampType)).as("hour"))
     
    		df
		.select(columns: _*)
		.writeStream
		.partitionBy("year", "month", "day", "hour")
		.format("parquet")
		.option("path", s"${storageRootPath}/data")
		.option("checkpointLocation", s"${storageRootPath}/checkpoint")
		.start()
		.awaitTermination()
		
	}
	
	

	def writeJDBC(df: DataFrame, JDBCUrl: String, JDBCTable: String, user: String, password: String): Future[Unit] = Future 
	{
    
		df
		.writeStream
		.foreachBatch 
		
		{
			(data: DataFrame, batchId: Long) =>data	.write
									.mode(SaveMode.Append)
									.format("jdbc")
									.option("driver", "org.postgresql.Driver")
									.option("url", JDBCUrl)
									.option("dbtable", JDBCTable)
									.option("user", user)
									.option("password", password)
									.save()
		}
		.start()
		.awaitTermination()

	}



	override def readAntenna(df: DataFrame): DataFrame = 
	{

		df
		.select(($"timestamp").cast(TimestampType), $"bytes", $"antenna_id")
		.withWatermark("timestamp", "30 seconds")
		.groupBy($"antenna_id", window($"timestamp", "5 minutes"))
		.agg(sum($"bytes").as("sum_bytes_antenna"))
		.select($"antenna_id", $"window.start".as("date"), $"sum_bytes_antenna")
		
	}



	override def userTX(df: DataFrame): DataFrame = 
	{
	
		df
		.select(($"timestamp").cast(TimestampType), $"bytes", $"id")
		.withWatermark("timestamp", "30 seconds")
		.groupBy($"id", window($"timestamp", "5 minutes"))
		.agg(sum($"bytes").as("sum_bytes_user"))
		.select($"id", $"window.start".as("date"), $"sum_bytes_user")
		
	}
  
  

	override def appTX(df: DataFrame): DataFrame = 
	{
	
		df
		.select(($"timestamp").cast(TimestampType), $"bytes", $"app")
		.withWatermark("timestamp", "30 seconds")
		.groupBy($"app", window($"timestamp", "5 minutes"))
		.agg(sum($"bytes").as("sum_bytes_app"))
		.select($"app", $"window.start".as("date"), $"sum_bytes_app")
	}
	
	

	def main(args: Array[String]): Unit = run(args)
	
}
